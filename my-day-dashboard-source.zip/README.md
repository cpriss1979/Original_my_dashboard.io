# My Day — GlowCode Studio

A personal dashboard for calendars, projects, reminders, bookmarks, notes, finances, and daily priorities.

## Run
Open index.html in a browser, or serve this folder with a static web server.

## Publish with GitHub Pages
1. Create a repository on GitHub.
2. Upload index.html, glowcode-logo.png, and .nojekyll to the repository root.
3. In Settings → Pages, choose Deploy from a branch, then main and / (root).
4. Open the URL GitHub provides.

Standard GitHub Pages hosting is public. The ChatGPT sign-in protection from the original hosted dashboard is not included in this static code.

Entries are stored in browser localStorage, not in GitHub. Export a backup from the original dashboard and restore it on the new URL to move your data. Reminders are dashboard checklists and do not send notifications. No calendar or bank integrations are included.

The logo is embedded in index.html for reliable display; glowcode-logo.png supplies the favicon. No dependencies or build step are required.
