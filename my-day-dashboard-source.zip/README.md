Upload index.html, glowcode-logo.png, and .nojekyll to GitHub Pages. No build needed. Standard Pages hosting is public. Data saves in your browser; export and restore backups to move it.
