My Day — GlowCode Studio

Upload index.html, glowcode-logo.png, and .nojekyll to GitHub Pages. No build required. Standard Pages hosting is public. Browser-local data can be moved using Export backup and Restore backup.

Finances now includes shared expenses: add people, record expenses, choose who paid and who shares the cost. Balances and settlement suggestions update automatically. Your personal ledger is retained separately. Payments are suggestions only.
